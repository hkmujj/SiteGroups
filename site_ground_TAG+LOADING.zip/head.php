<div id="header">
        	<h2>站群建设</h2>
    <div id="topmenu">
            	<ul>
                	<li class="current"><a href="index.php">后台首页</a></li>
                    <li><a href="#">站点管理</a></li>
                	<li><a href="users.html">模板管理</a></li>
                    <li><a href="#">批量处理</a></li>
                    <li><a href="#">会员信息</a></li>
                    <li><a href="#">系统设置</a></li>
                    <li><a href="#">在线升级</a></li>
                    <li><a href="#">备份还原</a></li>
                    <li><a href="#">帮助</a></li>
                    <li><a href="#">站点选择</a></li>
                    <li><a href="#">浏览站点</a></li>
                    <li><a href="#">注销登录</a></li>
              </ul>
          </div>
      </div>
        <div id="top-panel">
            <div id="panel">
                <ul>
                    <li><a href="#" class="report">建站报告</a></li>
                    <li><a href="#" class="report_seo">SEO Report</a></li>
                    <li><a href="#" class="search">Search</a></li>
                    <li><a href="#" class="feed">RSS Feed</a></li>
                </ul>
            </div>
      </div>