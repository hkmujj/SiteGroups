<div id="sidebar">
  				<ul>
                	<li><h3><a href="#" class="house">站点管理</a></h3>
                        <ul>
                        	<li><a href="#" class="report">关键字管理</a></li>
                    		<li><a href="#" class="report_seo">SEO 句管理</a></li>
                            <li><a href="#" class="search">数据库管理</a></li>
                            <li><a href="#" class="report_seo">伪静态管理</a></li>
                            <li><a href="#" class="search">统计代码</a></li>
                            <li><a href="#" class="search">站点版权/备案管理</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="folder_table">批量处理</a></h3>
          				<ul>
                        	<li><a href="site_batch.php" class="addorder">站点操作</a></li>
							<li><a href="site_collect.php" class="addorder">采集内容</a></li>
                          <li><a href="#" class="shipping">管理关键字</a></li>
                            <li><a href="#" class="invoices">更改SEO 句</a></li>
                            <li><a href="#" class="invoices">配置数据库</a></li>
                            <li><a href="#" class="invoices">伪静态处理</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="manage">模板管理</a></h3>
          				<ul>
                            <li><a href="#" class="manage_page">模板导入</a></li>
                            <li><a href="#" class="cart">移除模板</a></li>
                            <li><a href="#" class="folder">获取模板</a></li>
            				<li><a href="#" class="promotions">现有模板列表</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="manage">系统设置</a></h3>
          				<ul>
                            <li><a href="#" class="manage_page">系统设置1</a></li>
                            <li><a href="#" class="cart">系统设置2</a></li>
                            <li><a href="#" class="folder">系统设置3</a></li>
            				<li><a href="#" class="promotions">系统设置4</a></li>
                        </ul>
                    </li>
                     <li><h3><a href="#" class="folder_table">SEO数据</a></h3>
          				<ul>
                        	<li><a href="#" class="addorder">网站收录</a></li>
                          <li><a href="#" class="shipping">流量查询</a></li>
                            <li><a href="#" class="invoices">网站排名</a></li>
                            <li><a href="#" class="invoices">关键字排名</a></li>
                        </ul>
                    </li>
                  <li><h3><a href="#" class="user">会员管理</a></h3>
          				<ul>
                            <li><a href="#" class="useradd">增加管理员</a></li>
                            <li><a href="#" class="group">管理员权限</a></li>
            				<li><a href="#" class="search">会员信息</a></li>
                            <li><a href="#" class="online">获取帮助</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="folder_table">备份还原</a></h3>
          				<ul>
                        	<li><a href="#" class="addorder">备份数据库</a></li>
                          <li><a href="#" class="shipping">整站备份</a></li>
                            <li><a href="#" class="invoices">数据还原</a></li>
                        </ul>
                    </li>
                    <li><h3><a href="#" class="folder_table">在线升级</a></h3></li>
                     <li><h3><a href="#" class="folder_table">帮助</a></h3></li>
				</ul>       
          </div>
      </div>