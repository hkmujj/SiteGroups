<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>创建进度</title>
<style>
	.load_out{width:800px;height:120px;margin-left:auto;margin-right:auto;border:#A8A8A6 solid 1px;border-top:none;}
	.load_out h1{width:100%;height:26px;font-size:15px;background:#A8A8A6;text-align:center;padding-top:5px;font-family:"微软雅黑";}
	.load{width:100%;height:20px;}
	#loading{width:36%;background:red;height:20px;}
	#info{background:red;height:30px;margin-top:10px;}
</style>
</head>
<body>
	<div class="load_out">
		<h1>创建进度 </h1>	
		<div class="load"><div id="loading"></div> </div>
		<div id="info"></div>
	</div>
</body>
</html>