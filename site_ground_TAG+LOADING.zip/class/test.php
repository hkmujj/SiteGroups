<?php
/*
require_once "rank_css.php";
require_once "class_write_html.php";
$test = new COLOR;
$need = $test->creat_color();
print_r($need);
$need = $test->creat_tag(10);
echo $need;
$te = new WHTML;
$da = $te->write("testwebhtmlofwrite","c:/index.php","gbk");
echo $da;
*/
$ii = '192.186.16';
for($i=100;$i < 201;$i++){
	echo $ii.'.'.	$i.'<br>';
}
?>