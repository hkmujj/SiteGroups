$(function(){
	$(".chosen").chosen();
});
$("#cstart").click(function(){
alert(11123);
	var sport=$("#select_port").val();
	alert(sport);
});