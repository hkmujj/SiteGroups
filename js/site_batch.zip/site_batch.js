  $(document).ready(function(){
  $("#sitenums").blur(function(){
  var r = /^[0-9]*[1-9][0-9]*$/;
			nums = $("#sitenums").val();
			$("#muns").show();
			if(r.test(nums)){
				 $("#muns").replaceWith("<img src=\"img/icons/right.png\" id=\"muns\" />");
				 $('#sitenums').css("background", "#fff");
				 tenums=1; 
			}
			else{
				$("#muns").replaceWith("<img src=\"img/icons/shut.png\" id=\"muns\" />");
				tenums=0;
			}; 
	  });
	  $("#url_fan").click(function(){
			$('#fanyu').show();
			$("#main_url").show();
			$("#wwurl").hide();
		});
		$("#url_normal").click(function(){
			$('#fanyu').hide();
			$("#main_url").hide();
			$("#wwurl").show();
		});
		
	$("#creat_fanyu").click(function(){
	i = $('input:radio[name="rand_type"]:checked').val();
			if(i==0){
				rand_type=0;
			}
			else{
				rand_type=1;
			}
			i = $('input:radio[name="rand_url"]:checked').val();
			if(i==3){
				rand_url=3;
			}
			else if(i==4){
				rand_url=4;
			}
			else if(i==5){
				rand_url=5;
			}
			else{
				rand_url=6;
			}
		$.post("test/creat_fanyu.php",{rand_type:rand_type,rand_url:rand_url,nums:nums},function(data){
			alert(data);
			$("#fanyu").html(data);
		});
	});
	$("#seoselt").click(function(){
		$("#seosent").hide();
		$("#seosent2").show();
	});
	$("#seoselt2").click(function(){
		$("#seosent2").hide();
		$("#seosent").show();
	});
	$("#rewriteo").click(function(){
		$("#rewrite_h").show();
		$("#rewrite_f").show();
	});
	$("#rewritec").click(function(){
		$("#rewrite_h").hide();
		$("#rewrite_f").hide();
	})
	$("#wjsc").click(function(){
		$("#wjsr").hide();
		$("#wjsr2").show();
	});
	$("#wjso").click(function(){
		$("#wjsr").show();
		$("#wjsr2").hide();
	});
	$("#dbc").click(function(){
		$("#dbr2").show();
		$("#dbr").hide();
	});
	$("#dbo").click(function(){
		$("#dbr").show();
		$("#dbr2").hide();
	});
	$("#detest").click(function(){
			$("#dbte").show();
		   dbhost=$("#dbaddre").val();
			 dbuser=$("#dbuser").val();
			 dbpasswd=$("#dbpasswd").val();
			 i = $('input:radio[name="db"]:checked').val();
			if(i=="nomal"){
				dbr=$("#dbr2").val();
			}
			$.post("test/testdb.php",{dbhost:dbhost,dbuser:dbuser,dbpasswd:dbpasswd,dbr:dbr},function(data){
				alert(data);
				var ttt = data.split("\n");
			if(ttt[0]=="数据库连接成功")
			{
				$("#dbte").replaceWith("<img src=\"img/icons/right.png\" id=\"dbte\" />");
				tecndb=1; 
			}
			else
				{
				$("#dbte").replaceWith("<img src=\"img/icons/shut.png\" id=\"dbte\" />");
				tecndb=0;
			}; 	
			});	
		});
	$("#submit").click(function(){
  	var  dbhost= $("#dbaddre").val();
	var  dbuser=$("#dbuser").val();
	var dbpasswd=$("#dbpasswd").val();
	var keywords=$("#keywords").val();
	var wname=$("#wname").val();
	var channel=$("#channel").val();
	var wip=$("#wip").val();
	var wdir=$("#wdir").val();
	var wstyle=$("#wstyle").val();
	var wsub=$("#wsub").val();
	var wfked=$("#wfkey").val();
	wname=wsplit(wname);
	keywords=wsplit(keywords);
	
	channel=wsplit(channel);
	
	wip=wsplit(wip);
	
	wdir=wsplit(wdir);
	
	wstyle=wsplit(wstyle);
	
	wsub=wsplit(wsub);
	
	wfked=wsplit(wfked);
	alert(1123);
	
	i = $('input:radio[name="urltype"]:checked').val();
	if(i == "nomal"){
		var urls=$("#wwurl").val();
		urls=wsplit(urls);
		var urltype="";
		var fanyus=0;
	}
	else{
		var urls=$("#main_url").val();
		var urltype=$("#fanyu").val();
		var fanyus=1;
	}
		
	i = $('input:radio[name="seotype"]:checked').val();
		if(i=="nomal"){
			var seotype=$("#seosent2").val();
		}
		else{
		seotype=$("#seosent").val();
		seotype=wsplit(seotype);
		}
	i = $('input:radio[name="rewrite"]:checked').val();
	if(i=="nomal"){
		rewrites=1;
		var rewrite_h=$("#rewrite_h").val();
		var rewrite_f=$("#rewrite_f").val();
		rewrite_h=wsplit(rewrite_h);
		rewrite_f=wsplit(rewrite_f);
	}
	else{
		rewrites=0;
		rewrite_h="";
		rewrite_f="";
	}
	i = $('input:radio[name="wjs"]:checked').val();
	if(i=="nomal"){
		var wjs=$("#wjsr2").val();
	}
	else{
		wjs=$("#wjsr").val();
		wjs=wsplit(wjs);
	}
	i = $('input:radio[name="db"]:checked').val();
	if(i=="nomal"){
		dbr=$("#dbr2").val();
	}
	else{
		dbr=$("#dbr").val();
		dbr=wsplit(dbr);
	}
	//alert(dbr);
	if(typeof wdir == 'undefined'| wdir.length==0 | wdir==""){
		var tewdir=0;
	}
	else {
		var tewdir=1;
	}
	if(typeof dbr == 'undefined'| dbr.length==0 | dbr==""){
		var tedbr=0;
	}
	else {
		var tedbr=1;
	}
	if(typeof wname == 'undefined'| wname.length==0 | wname==""){
		var tewname=0;
	}
	else {
		var tewname=1;
	}
	if(typeof urls == 'undefined'| urls.length==0 | urls==""){
		var teurls=0;
	}
	else {
		var teurls=1;
	}
	if(typeof nums == 'undefined'){
		tenums=0;
	}
	
	serror=0;
	subcheck(tenums,"#sitenums");
	subcheck(tedbr,"#dbr");		
	subcheck(tewdir,"#wdir");
	subcheck(tewname,"#wname");
	serror=0;
	if(serror==0){
	 $.post("creatwebs/creat.php?step=1",{dbhost:dbhost,dbuser:dbuser,dbpasswd:dbpasswd,nums:nums,urltype:urltype,seotype:seotype,keywords:keywords,wname:wname,channel:channel,urls:urls,wip:wip,wdir:wdir,wstyle:wstyle,rewrites:rewrites,rewrite_h:rewrite_h,rewrite_f:rewrite_f,fanyus:fanyus,wjs:wjs,wsub:wsub,wfked:wfked,dbr:dbr},function(data){
	 alert(data);
				var re =new RegExp(/[\d]+.xls/);
				var nus = nums;
				excfile = data.match(re);
				$("#iinfo").show();
				$("#showinfo").html(data);	
			}); 
	  }
	  else{
		alert("填入必要信息以及测试数据库连接");
	  }
	});
	});
	function wsplit(fdata){
		var arr = fdata.split('\n');
		//删除空白元素
		for(i=0;i <= (arr.length-1);i++){
			var j = (arr.length-1)
			if(arr[i]==""){
				arr.splice(i,1);	
			}
		}
		return arr;
	}
	function subcheck(te,lable){
		if(te != 1){
			serror+=1;
			$(lable).css("background", "pink");
		}	
	}